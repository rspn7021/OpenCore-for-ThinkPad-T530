# Lenovo ThinkPad T530 OpenCore

> **Tested with**: macOS 10.13 to 15.x</br>
> **Recommended OS**: macOS Big Sur </br>
> **Recommended SMBIOS**: `MacBookPro10,1` (for Core i7), `MacBookPro10,2` (for Core i5)

To configure this EFI correctly before deployment, follow the instructions on my [**GitHub Repo**](https://github.com/5T33Z0/Lenovo-T530-Hackinosh-OpenCore).

## Changelog

### 2025-05-17: Maintenance Update (fixing BT again… for good)
- Updated OpenCore and drivers to 1.0.5 nightly
- Disabled currently unnecessary boot-args
- Updated BrcmPatchRAM kexts to 2.7.1
- Added `-btlfxboardid` so that Bluetooth works with BrcmPatchRAM kexts 2.7.0+

> [!IMPORTANT]
>
> - Reset NVRAM on first time boot
> - Apply Root Patches with OCLP in Post-Install to get working graphics acceleration (macOS 12+) and Wi-Fi (macOS 14+)
> - Change `hibernatemode` from `0` to `25` (or `3`) in Post-Install via `pmset` or Hackintool to enable hibernation! ([**More Details**](https://github.com/5T33Z0/OC-Little-Translated/tree/main/04_Fixing_Sleep_and_Wake_Issues/Changing_Hibernation_Modes))

> [!CAUTION]
> 
> - DON'T update `VoodooPS2Controller.kext`
> - DON'T update `VoodooSDHC.kext`
> - DON'T use `YogaSMC.kext` – it crashes the system on boot since it requires Acidanthera's version of VoodooPS2Controller which doesn't work well with the T530's TrackPad.
> - DON'T install Security Response Updates (RSR) introduced in macOS 13! They will fail to install on pre-Haswell systems. More info [**here**](https://github.com/dortania/OpenCore-Legacy-Patcher/issues/1019).

### 2025-04-15: Fixing BT
- **Downgraded** the following kexts to version `2.6.9` to fix Bluetooth since it stopped working somewhere betweeen 2.7.0 and 2.7.1 (further investigation required):
	- `BluetootBlueToolFixup.kext`
	- `BrcmBluetoothInjector.kext`
	- `BrcmFirmwareData.kext`
	- `BrcmPatchRAM2.kext`
	- `BrcmPatchRAM3.kext`

> [!IMPORTANT]
>
> - Reset NVRAM on first time boot
> - Apply Root Patches with OCLP in Post-Install to get working graphics acceleration (macOS 12+) and Wi-Fi (macOS 14+)
> - Change `hibernatemode` from `0` to `25` (or `3`) in Post-Install via `pmset` or Hackintool to enable hibernation!

> [!CAUTION]
> 
> - DON'T install Security Response Updates (RSR) introduced in macOS 13! They will fail to install on pre-Haswell systems. More info [**here**](https://github.com/dortania/OpenCore-Legacy-Patcher/issues/1019).
> - DON'T update `VoodooPS2Controller.kext`
> - DON'T update `VoodooSDHC.kext`
> - DON'T use `YogaSMC.kext` – it crashes the system on boot since it requires Acidanthera's version of VoodooPS2Controller which doesn't work well with the T530's TrackPad.

### 2025-03-31: Maintainance Update
- Updated OpenCore to v1.0.5 nightly
- Updated Drivers and Kexts
- Tested with macOS Sonoma 14.7.5 (23H527) and Sequoia 15.4

> [!IMPORTANT]
>
> - Reset NVRAM on first time boot
> - Apply Root Patches with OCLP in Post-Install to get working graphics acceleration (macOS 12+) and Wi-Fi (macOS 14+)
> - Change `hibernatemode` from `0` to `25` (or `3`) in Post-Install via `pmset` or Hackintool to enable hibernation!

> [!CAUTION]
> 
> - DON'T install Security Response Updates (RSR) introduced in macOS 13! They will fail to install on pre-Haswell systems. More info [**here**](https://github.com/dortania/OpenCore-Legacy-Patcher/issues/1019).
> - DON'T update `VoodooPS2Controller.kext`
> - DON'T update `VoodooSDHC.kext`
> - DON'T use `YogaSMC.kext` – it crashes the system on boot since it requires Acidanthera's version of VoodooPS2Controller which doesn't work well with the T530's TrackPad.

### 2025-03-13: Maintainance Update
- Updated OpenCore to v1.0.5 nightly
- Updated Drivers and Kexts
- Tested with macOS Sonoma 14.7.5 (23H515) and Sequoia 15.3.2 (24D81)

> [!IMPORTANT]
>
> - Reset NVRAM on first time boot
> - Apply Root Patches with OCLP in Post-Install to get working graphics acceleration (macOS 12+) and Wi-Fi (macOS 14+)
> - Change `hibernatemode` from `0` to `25` (or `3`) in Post-Install via `pmset` or Hackintool to enable hibernation!

> [!CAUTION]
> 
> - DON'T insatll Sequoia 15.4.0 Dev beta. OCLP isn't compatible yet!
> - DON'T install Security Response Updates (RSR) introduced in macOS 13! They will fail to install on pre-Haswell systems. More info [**here**](https://github.com/dortania/OpenCore-Legacy-Patcher/issues/1019).
> - DON'T update `VoodooPS2Controller.kext`
> - DON'T update `VoodooSDHC.kext`
> - DON'T use `YogaSMC.kext` – it crashes the system on boot since it requires Acidanthera's version of VoodooPS2Controller which doesn't work well with the T530's TrackPad.

### 2025-02-08: Finally got Hibernation working (and other refinements)
- Updated OpenCore to v1.0.4 nightly
- Updated Drivers and Kexts
- Tested with macOS Sonoma 14.7.3 and Sequoia 15.3
- Fixed Hibernation. hibernatemode 25 is working but you need to [configure it](https://github.com/5T33Z0/OC-Little-Translated/tree/main/04_Fixing_Sleep_and_Wake_Issues/Changing_Hibernation_Modes#configuring-hibernation) via pmset.
- **ACPI**:
	- Integrated contents of `SSDT-NBCF.aml` into `SSDT-PNLF`, so `BrightnessKeys.kext` works
	- Deleted `SSDT-NBCF` &rarr; no longer needed
- **NVRAM**:
	- Changed `hbfx-ahbm` to `55` 

> [!IMPORTANT]
>
> - Reset NVRAM on first time boot
> - Apply Root Patches with OCLP in Post-Install to get working graphics acceleration (macOS 12+) and Wi-Fi (macOS 14+)
> - Change `hibernatemode` from `0` to `25` (or `3`) in Post-Install via pmset or Hackintool to enable hibernation!
> - Don't update `VoodooPS2Controller.kext`
> - Don't update `VoodooSDHC.kext`
> - Don't use `YogaSMC.kext` – it crashes the system on boot since it requires Acidanthera's version of VoodooPS2Controller which doesn't work well with the T530's TrackPad.

> [!CAUTION]
>
> - Don't install Security Response Updates (RSR) introduced in macOS 13! They will fail to install on pre-Haswell systems. More info [**here**](https://github.com/dortania/OpenCore-Legacy-Patcher/issues/1019).
> - Don't update `VoodooPS2Controller.kext`
> - Don't update `VoodooSDHC.kext`
> - Don't use `YogaSMC.kext` – it crashes the system on boot since it requires Acidanthera's version of VoodooPS2Controller which doesn't work well with the T530's TrackPad.

### 2024-12-15: Maintenance update and new issues

- Updated OpenCore to v1.0.3 nightly
- Updated Drivers and Kexts
- Tested with macOS Sonoma 14.7.2 and Sequoia 15.2
- Deleted unused themes (Syrah, Chardonny and Enter Twilight)
- Updated GoldenGate theme with macOS 15 icons 
- **Issues**: 
	- The SDCard Reader kext (`VoodooSDHC`) stopped working somewhere between Big Sur and Sonoma. No fix in sight.
	- BT is still causing issues in Sonoma and Sequoia. It can detect devices but not connect to them.

> [!IMPORTANT]
>
> - Reset NVRAM on first time boot
> - Apply Root Patches with OCLP in Post-Install to get working graphics acceleration (macOS 12+) and Wi-Fi (macOS 14+)
> - Change `hibernatemode` from `0` to `25` (or `3`) in Post-Install via pmset or Hackintool to enable hibernation!
> - Don't update `VoodooPS2Controller.kext`
> - Don't update `VoodooSDHC.kext`
> - Don't use `YogaSMC.kext` – it crashes the system on boot since it requires Acidanthera's version of VoodooPS2Controller which doesn't work well with the T530's TrackPad.

### 2024-10-25: BT fix for Sequoia
- Updated OpenCore to v1.0.3 nightly
- Updated Drivers and Kexts
- Tested with macOS Sonoma and Sequoia
- Deleted `AdvancedMap_Sonoma.kext`
- Deleted `AdvancedMap_Sequoia.kext`
- Compiled and added `AdvancedMap.kext` compatible with macOS Monterey and newer
- Added NVRAM Parameters so BT is available in Sequoia

> [!IMPORTANT]
>
> - Reset NVRAM on first time boot
> - Apply Root Patches with OCLP in Post-Install to get working graphics acceleration (macOS 12+) and Wi-Fi (macOS 14+)
> - Change `hibernatemode` from `0` to `25` (or `3`) in Post-Install via pmset or Hackintool to enable hibernation!
> - Don't update `VoodooPS2Controller.kext`
> - Don't update `VoodooSDHC.kext`
> - Don't use `YogaSMC.kext` – it crashes the system on boot since it requires Acidanthera's version of VoodooPS2Controller which doesn't work well with the T530's TrackPad.

<details>
<summary><strong>Previous Changes</strong> (click to reveal)</summary>

### 2024-09-02: Sequoia Support
- Updated OpenCore to v1.0.2 nightly
- Updated Drivers and Kexts
- Added `AdvancedMap.kext` v4.0 and renamed it to `AdvancedMap_Sequoia.kext`
- Renamed `AdvancedMap.kext` v3.0 to `AdvancedMap_Sonoma.kext`
- Requires Nightly build of OCLP from Sequoia Development Branch ([details](https://github.com/5T33Z0/Lenovo-T530-Hackintosh-OpenCore/issues/50#issuecomment-2325200008))

> [!IMPORTANT]
>
> - Apply Root Patches with OCLP in Post-Install to get working graphics acceleration (macOS 12+) and Wi-Fi (macOS 14)
> - Change `hibernatemode` from `0` to `25` (or `3`) in Post-Install via pmset or Hackintool to enable hibernation!

>[!CAUTION]
>
> - Don't install Security Response Updates (RSR) introduced in macOS 13! They will fail to install on pre-Haswell systems. More info [**here**](https://github.com/dortania/OpenCore-Legacy-Patcher/issues/1019).
> - Don't update `VoodooPS2Controller.kext`
> - Don't update `VoodooSDHC.kext`
> - Don't use `YogaSMC.kext` – it crashes the system on boot since it requires Acidanthera's version of VoodooPS2Controller which doesn't work well with the T530's TrackPad.


### 2024-08-20: Maintenance update
Tested successfully with macOS Sonoma 14.6.1. Use OCLP 1.6.0 Nightly or newer for root patching!

- Updated OpenCore to v1.0.2 nightly
- Updated Drivers and Kexts

> [!IMPORTANT]
>
> - Apply Root Patches with OCLP in Post-Install to get working graphics acceleration (macOS 12+) and Wi-Fi (macOS 14)
> - Change `hibernatemode` from `0` to `25` (or `3`) in Post-Install via pmset or Hackintool to enable hibernation!

>[!CAUTION]
>
> - Don't install Security Response Updates (RSR) introduced in macOS 13! They will fail to install on pre-Haswell systems. More info [**here**](https://github.com/dortania/OpenCore-Legacy-Patcher/issues/1019).
> - Don't update `VoodooPS2Controller.kext`
> - Don't update `VoodooSDHC.kext`
> - Don't use `YogaSMC.kext` – it crashes the system on boot since it requires Acidanthera's version of VoodooPS2Controller which doesn't work well with the T530's TrackPad.

### 2024-02-18: OC 0.9.9 Maintenance update for macOS 14.4 beta support
Tested successfully with macOS Mojave to Sonoma 14.4 beta. Use OCLP 1.4.0 Nightly or newer for patching!

- Updated OpenCore to 0.9.9 Nightly
- Updated `IOSkywalkFamily.kext`

> [!IMPORTANT]
>
> - Apply Root Patches with OCLP in Post-Install to get working graphics acceleration (macOS 12+) and Wi-Fi (macOS 14)
> - Change `hibernatemode` from `0` to `25` (or `3`) in Post-Install via pmset or Hackintool to enable hibernation!

>[!CAUTION]
>
> - Don't install Security Response Updates (RSR) introduced in macOS 13! They will fail to install on pre-Haswell systems. More info [**here**](https://github.com/dortania/OpenCore-Legacy-Patcher/issues/1019).
> - Don't update `VoodooPS2Controller.kext`
> - Don't update `VoodooSDHC.kext`
> - Don't use `YogaSMC.kext` – it crashes the system on boot since it requires Acidanthera's version of VoodooPS2Controller which doesn't work well with the T530's TrackPad.

### 2023-12-14: OC 0.9.8 Maintenance update for macOS 14.3 support
Tested successfully with macOS Mojave to Sonoma 14.3. Use OCLP 1.3.0 or newer for patching!

- Updated OpenCore to 0.9.8 Nightly
- Updated `Drivers` and `Kexts`

> [!IMPORTANT]
>
> - Apply Root Patches with OCLP in Post-Install to get working graphics acceleration (macOS 12+) and Wi-Fi (macOS 14)
> - Change `hibernatemode` from `0` to `25` (or `3`) in Post-Install via pmset or Hackintool to enable hibernation!

>[!CAUTION]
>
> - Don't install Security Response Updates (RSR) introduced in macOS 13! They will fail to install on pre-Haswell systems. More info [**here**](https://github.com/dortania/OpenCore-Legacy-Patcher/issues/1019).
> - Don't update `VoodooPS2Controller.kext`
> - Don't update `VoodooSDHC.kext`
> - Don't use `YogaSMC.kext` – it crashes the system on boot since it requires Acidanthera's version of VoodooPS2Controller which doesn't work well with the T530's TrackPad.

### 2023-12-05: Fixed idle sleep and Hibernation!
Tested successfully with macOS Mojave to Sonoma 14.2 beta 4. Use OCLP 1.3.0 [beta](https://github.com/dortania/OpenCore-Legacy-Patcher/blob/main/SOURCE.md) for patching! Thanks to @jozews321 for fixing hibernation.

- Updated OpenCore to 0.9.7 Nightly
- Updated `Drivers` and `Kexts`
- **CONFIG**
	- `Kernel/Patch`: Disabled "RTC Wake Scheduling" patch. No longer needed.
	- `Misc/Boot`: Enabled `HibernateSkipsPicker` for a more seamless wake from hibernation.
	- `Misc/Boot/HibernateMode`: Changed it from `Auto` to `NVRAM` &rarr; Fixes idle sleep
	- `NVRAM/Add`: Changed `hbfx-ahbm` from `1` to `129` &rarr; Prohibits the system from full wake when attempting to transition from `S3` to `S4` sleep state (hibernation). Only relevant for `hibernatemode 3`.
	- `UEFI/ReservedMemory`: Added entry &rarr; Fixes black screen issue after waking from hibernation (enable if needed)

> [!IMPORTANT]
>
> - Apply Root Patches with OCLP in Post-Install to get working graphics acceleration (macOS 12+) and Wi-Fi (macOS 14)
> - Change `hibernatemode` from `0` to `25` (or `3`) in Post-Install via pmset or Hackintool to enable hibernation!

>[!CAUTION]
>
> - Don't install Security Response Updates (RSR) introduced in macOS 13! They will fail to install on pre-Haswell systems. More info [**here**](https://github.com/dortania/OpenCore-Legacy-Patcher/issues/1019).
> - Don't update `VoodooPS2Controller.kext`
> - Don't update `VoodooSDHC.kext`
> - Don't use `YogaSMC.kext` – it crashes the system on boot since it requires Acidanthera's version of VoodooPS2Controller which doesn't work well with the T530's TrackPad.

### 2023-11-30: New IRQ Fix
Tested successfully with macOS Mojave to Sonoma 14.2 beta 4. Use OCLP 1.3.0 [beta](https://github.com/dortania/OpenCore-Legacy-Patcher/blob/main/SOURCE.md) for patching!

- Updated OpenCore to 0.9.7 Nightly
- Updated `Drivers` and `Kexts`
- **ACPI**
	- Replaced `SSDT-IRQ-FIXES.aml` by a newer, more elegant fix ([Explanations](https://github.com/5T33Z0/OC-Little-Translated/tree/main/01_Adding_missing_Devices_and_enabling_Features/IRQ_and_Timer_Fix_(SSDT-HPET)#method-22-patching-with-ssdt-irq_fixes_think-if-hpaehpte-does-not-exist))

> [!CAUTION]
>
> - Apply Root Patches with OCLP in Post-Install to get working graphics acceleration (macOS 12+) and Wi-Fi (macOS 14)
> - Change `hibernatemode` to `25` to enable Hibernation in Post-Install!
> - Don't install Security Response Updates (RSR) introduced in macOS 13! They will fail to install on pre-Haswell systems. More info [**here**](https://github.com/dortania/OpenCore-Legacy-Patcher/issues/1019).
> - Don't update `VoodooPS2Controller.kext`
> - Don't update `VoodooSDHC.kext`
> - Don't use `YogaSMC.kext` – it crashes the system on boot since it requires Acidanthera's version of VoodooPS2Controller which doesn't work well with the T530's TrackPad.

### 2023-11-26: New Kernel Patches
- Updated OpenCore to 0.9.7 Nightly
- Updated `Drivers` and `Kexts`
- Tested successfully with macOS Mojave to Sonoma 14.1 (23B74)
- **CONFIG**
	- **Kernel/Patch**
		- Added "Fix PCI bus enumeration" Patches &rarr; Fixes internal PCIe devices showing up as express cards in the menubar in macOS 13+ (optional).  

> [!CAUTION]
>
> - Apply Root Patches with OCLP in Post-Install to get working graphics acceleration (macOS 12+) and Wi-Fi (macOS 14)
> - Change `hibernatemode` to `25` to enable Hibernation in Post-Install!
> - Don't install Security Response Updates (RSR) introduced in macOS 13! They will fail to install on pre-Haswell systems. More info [**here**](https://github.com/dortania/OpenCore-Legacy-Patcher/issues/1019).
> - Don't update `VoodooPS2Controller.kext`
> - Don't update `VoodooSDHC.kext`
> - Don't use `YogaSMC` – it crashes the system on boot since it requires Acidanthera's version of VoodooPS2Controller which doesn't work well with the T530's TrackPad.

### 2023-11-04: Config Cleanup
- Updated OpenCore to 0.9.6 Nightly
- Updated `Drivers` and `Kexts`
- Tested successfully with macOS Mojave to Sonoma 14.1 (23B74)
- **CONFIG**
	- **ACPI/Add** 
		- Deleted `SSDT-ARPT` &rarr; Remnant from previous Wifi spoofing tests
		- Deleted `SSDT-PWRB` &rarr; Unncecessary Power Button Device
	- **ACPI/Patch**
		- Disabled "EHC1 to EH01" rename &rarr; Unnecessary
		- Disabled "EHC2 to EH02" rename &rarr; Unnecessary
		- Disabled "PSXS to ARPT" rename &rarr; Remnant from previous Wifi spoofing tests
	- **Kernel/Patch**
  		- Deleted unnecessary VVM board-id spoof Kernel Patches &rarr; Handled by `RestrictEvents.kext` now. 
	- **PlatfornInfo/Generic**
		- Disabled `AdviseFeatures` &rarr; Unnecessary
	- **NVRAM**
		- Deleted unncecessary boot-args	 

> [!IMPORTANT]
>
> - You need to install macOS 13+ via USB installer. Otherwise the installer will get [stuck in an error loop](https://github.com/5T33Z0/Lenovo-T530-Hackintosh-OpenCore/issues/43#issuecomment-1789736804). Instructions for installing macOS 11 and newer are [available on my repo](https://github.com/5T33Z0/Lenovo-T530-Hackintosh-OpenCore/tree/main/macOS_Install)
> - Apply Root Patches with OCLP in Post-Install to get working graphics acceleration (macOS 12+) and Wi-Fi (macOS 14)
> - **Kexts**:
> - Change `hibernatemode` to `25` to enable Hibernation in Post-Install!

> [!WARNING]
> 
> - Don't install Security Response Updates (RSR) introduced in macOS 13! They will fail to install on pre-Haswell systems. More info [**here**](https://github.com/dortania/OpenCore-Legacy-Patcher/issues/1019).
> - Don't update `VoodooPS2Controller.kext`
> - Don't update `VoodooSDHC.kext`
> - Don't use `YogaSMC` – it crashes the system on boot since it requires Acidanthera's version of VoodooPS2Controller which doesn't work well with the T530's TrackPad.

### 2023-10-23: Sonoma 14.0 working

- Updated OpenCore to 0.9.6 Nightly
- Updated `Drivers` and `Kexts`
- Tested successfully with macOS Mojave to Sonoma 14.0 (23A344) 
- **CONFIG**
	- Deleted Boad-id VMM spoof Kernel Patches &rarr; Handled by RestrictEvens.kext and revpatch:sbvmm NVRAM parameter
	- Disabled unnecessary Kernel Patches
- **KEXTS**:
	- Added `AdvancedMap` &rarr; Enables 3D Globe in macOS 12+  

**NOTES**

- Instructions for installing macOS 11 and newer are [available on my repo](https://github.com/5T33Z0/Lenovo-T530-Hackintosh-OpenCore/tree/main/macOS_Install)
- Don't update `VoodooPS2Controller.kext` and `VoodooSDHC.kext`
- Don't use `YogaSMC` – it crashes the system on boot since it requires Acidanthera's version of VoodooPS2Controller which doesn't work well with the T530's TrackPad.
- Change `hibernatemode` to `25` to enable Hibernation!
- ⚠️ Don't install Security Response Updates (RSR) introduced in macOS 13! They will fail to install on pre-Haswell systems. More info [**here**](https://github.com/dortania/OpenCore-Legacy-Patcher/issues/1019).

### 2023-08-02: Broadcom Wifi working in Sonoma

- Updated OpenCore to 0.9.4 Nightly
- Updated `Drivers` and `Kexts`
- Tested successfully with macOS Mojave to Sonoma.

### Instructions
- Download my EFI Folder
- Boot with it
- Make sure you are connected via Ethernet, because WiFi requires Root Patching in Sonoma!
- Follow the [instructions](https://www.insanelymac.com/forum/topic/357087-macos-sonoma-wireless-issues-discussion/page/15/#comment-2809431) to enable WiFI Root patching in OCLP
- Apply Root Patches
- Reboot 
- Enjoy!

**NOTES**

- Instructions for installing macOS 11 and newer are [available on my repo](https://github.com/5T33Z0/Lenovo-T530-Hackintosh-OpenCore/tree/main/macOS_Install)
- Don't update `VoodooPS2Controller.kext` and `VoodooSDHC.kext`
- Don't use `YogaSMC` – it crashes the system on boot since it requires Acidanthera's version of VoodooPS2Controller which doesn't work well with the T530's TrackPad.
- Change `hibernatemode` to `25` to enable Hibernation!
- ⚠️ Don't install Security Response Updates (RSR) introduced in macOS 13! They will fail to install on pre-Haswell systems. More info [**here**](https://github.com/dortania/OpenCore-Legacy-Patcher/issues/1019).

### 2023-07-24: Switch to Intel WiFi
- Updated OpenCore to 0.9.4 Nightly
- Updated `Drivers` and `Kexts`
- Tested successfully with macOS Mojave to Sonoma.
- **KEXTS**
	- Deleted all Broadcom-related kexts
	- Added itlwm.kext. &rarr; Requires HeliPort App to connect to WiFi Networks 
- **RESOURCES**
	- Added more icons to GoldenGate theme
	- Added Terminus Fonts

**NOTES**

- Instructions for installing macOS 11 and newer are [available on my repo](https://github.com/5T33Z0/Lenovo-T530-Hackintosh-OpenCore/tree/main/macOS_Install)
- Don't update `VoodooPS2Controller.kext` and `VoodooSDHC.kext`
- Don't use `YogaSMC` – it crashes the system on boot since it requires Acidanthera's version of VoodooPS2Controller which doesn't work well with the T530's TrackPad.
- Change `hibernatemode` to `25` to enable Hibernation!
- ⚠️ Don't install Security Response Updates (RSR) introduced in macOS 13! They will fail to install on pre-Haswell systems. More info [**here**](https://github.com/dortania/OpenCore-Legacy-Patcher/issues/1019).


### 2023-06-10: Goin' back to Cali…
- Updated OpenCore to 0.9.3 Nightly
- Updated `Drivers` and `Kexts`
- Tested successfully with macOS Mojave to ~~Ventura~~ Sonoma.
- **CONFIG**
	- Updated `MinKernel`/`MaxKernel` settings to Broadcom Kexts 
	- `Misc/ProtocolOverrides`: Enabled `PciIo` &rarr; Addresses bugs related to [4G Decoding in Ivy Bridge](https://github.com/acidanthera/OpenCorePkg/pull/459)
	- Moved `brcmfx-country` from boot-args to `DevicePropteries` of the Wifi/BT card to reduce clutter
- **KEXTS**:
	- Replaced BluetoolFixup from Acidanthera by the one from [zxystd](https://github.com/zxystd/BrcmPatchRAM/actions/runs/5218453965) because it work in Sonoma already.

**Notes**:

- R.I.P Broadcom WiFi Support (for now). Intel itlwm works fine (if you have a compatible card)
- Bluetooth Should still work
- Previous Notes still apply

### 2023-05-24: Fixing AMFI and tying up loose ends

- Updated OpenCore to 0.9.3 Nightly
- Updated `Drivers` and `Kexts`
- Tested successfully with macOS Mojave to Ventura
- **EFI/BOOT**
	- Added hidden files `.contentFlavour` and `.contentVisibility` introduced in OC 0.8.8. (press <kbd>⌘</kbd>+<kbd>⇧</kbd>+<kbd>.</kbd> to show them). OCAT excludes these from sync, so they were missing. Refer to Open Core's Documentation for details.
- **ACPI**
	- Added `SSDT-EXP1-disable` &rarr; Disables Express Card 1 slot (EXP1) in macOS (EXP2 is used for WiFi).  
	- Removed `DVL0` from `SSDT-SBUS-MCHC` &rarr; This device is useless on Wintel Systems. See OC [Pull Request #442](https://github.com/acidanthera/OpenCorePkg/pull/442) for details.
- **CONFIG**
	- Removed `amfi_get_out_of_my_way=0x1` &rarr; No longer required
- **KEXTS**
	- Added `AMFIPass.kext` &rarr; Brand new kext from OCLP. Allows booting macOS 12+ without disabling AMFI. Works.

**NOTES**

- Instructions for installing macOS 11 and newer are [available on my repo](https://github.com/5T33Z0/Lenovo-T530-Hackintosh-OpenCore/tree/main/macOS_Install)
- Don't update `VoodooPS2Controller.kext` and `VoodooSDHC.kext`
- Don't use `YogaSMC` – it crashes the system on boot since it requires Acidanthera's version of VoodooPS2Controller which doesn't work well with the T530's TrackPad.
- Change `hibernatemode` to `25` to enable Hibernation!
- ⚠️ Don't install Security Response Updates (RSR) introduced in macOS 13! They will fail to install on pre-Haswell systems. More info [**here**](https://github.com/dortania/OpenCore-Legacy-Patcher/issues/1019).

### 2023-04-30: NVRAM and other refinements
- Updated OpenCore to 0.9.2 Nightly
- Updated `Drivers` and `Kexts`
- Tested successfully with macOS Mojave to Ventura
- **CONFIG**
	- **Kernel/Patch**
		- Added patch to disable RTC Wake Scheduling &rarr; Resolves waking up from sleep due to RTC/HID activity.
	- **NVRAM/Add**
		- Changed `csr-active-config` to `03080000` &rarr; Minimum requirement for OCLP to work. More secure than the previous value.
		- Deleted `diskread` boot-arg. Unnecessary.
		- Deleted `f16c`from `revpatch` &rarr; Only relevant for Metal 1 GPUs (Intel HD 4000 supports Metal 2).
		- Created Dictionary for GUID `E09B9297-7928-4440-9AAB-D1F8536FBF0A` &rarr; for storing `HibernationFixup.kext` flags
		- Moved `hbfx-ahbm` flag for HibernationFixup from `boot-args`to said GUID
		- Moved `memtab` argument for RestrictEvents from `boot-args` to `revpatch` in GUID `4D1FDA02-38C7-4A6A-9CC6-4BCCA8B30102`
	- **NVRAM/Delete**
		- Created Array `E09B9297-7928-4440-9AAB-D1F8536FBF0A`
		- Added String `hbfx-ahbm` to said array so new/changed flags can be written

**NOTES**

- Instructions for installing macOS 11 or newer are [available on my repo](https://github.com/5T33Z0/Lenovo-T530-Hackintosh-OpenCore/tree/main/macOS_Install)
- Don't update `VoodooPS2Controller.kext` and `VoodooSDHC.kext`
- Don't use YogaSMC – it crashes the system on boot since it requires Acidanthera's version of VoodooPS2Controller which doesn't work well with this TrackPad.
- Change `hibernatemode` to `25` to enable Hibernation!
- ⚠️ You cannot install macOS Security Response Updates (RSR) on pre-Haswell Systems. These kind of update will just fail to install (more info [**here**](https://github.com/dortania/OpenCore-Legacy-Patcher/issues/1019)).

### 2023-04-23: 2 binary renames less
- Updated OpenCore to 0.9.2 Nightly
- Updated `Drivers` and `Kexts`
- Tested successfully with macOS Mojave to Ventura
- **ACPI**
	- **Simplified IRQ fixes**. The original patch to disable `HPET` consisted of binary renames to rename `WNTF` to `XXXX` and `WXPF` to `YYYY` and then using `SSDT-IRQ_FIXES` which utilizes `If (!_OSI ("Darwin"))` to restore the original names for every other OS that is *not* macOS (indicated by the "!"). But it's much simpler to only change the names in `HPET` only if macOS is running. So I changed the rule to `If (_OSI ("Darwin"))` and switched the order from `XXXX = WNTF` to `WNTF = XXXX` and did the same for            `WXPF`.
- **CONFIG**
	- **ACPI/Patch**
		- Removed 2 binary renames for renaming `WNTF` to `XXXX` and `WXPF` to `YYYY` &rarr; No longer required.

### 2023-04-23: `AppleCpuPmCfgLock` fixed in OC 0.9.2
- Just a small maintenance update including the latest nightly build of OpenCore 0.9.2 which fixes the `AppleCpuPmCfgLock` quirk in macOS Ventura so flashing a modified BIOS in order to re-enable legacy CPU Power Management in macOS Ventura is no longer a requirement.
- Tested successfully with macOS Mojave to Ventura

**NOTES**

- Don't update `VoodooPS2Controller.kext` and `VoodooSDHC.kext`
- Follow `OC macOS Ventura Install Instructions.md` for installing macOS 13
- Change `hibernatemode` to `25` to enable Hibernation!
- ⚠️ You cannot install macOS Security Response Updates (RSR) on pre-Haswell Systems. These kind of update will just fail to install (more info [**here**](https://github.com/dortania/OpenCore-Legacy-Patcher/issues/1019)).

### 2023-04-16: Fixing OC GUI issues. More macOS 13 improvements.
- Updated OpenCore to 0.9.2 Nightly
- Updated `Drivers` and `Kexts`
- Updated Config to reflect latest OpenCore feature-set
- Tested successfully with macOS Mojave to Ventura
- **CONFIG**
	- **Kernel/Patch**: Added patch for enabling SATA hot plugging (disabled)
	- **NVRAM**:
		- Added `f16c`to `revpatch` &rarr; Disables F16C reporting on Ivy Bridge in macOS 13.3+. More info [here](https://github.com/acidanthera/RestrictEvents/pull/12)
		- Added `amfi_get_out_of_my_way=0x1` boot-arg. Required for:
			- Root Patching with OpenCore Legacy Patcher 
			- Booting macOS 13. Otherwise the boot process just stalls forever when trying to enter the 2nd boot stage.
	- **UEFI/Output**:
		- Enabled `DirectGopRendering` to make the OpenCore GUI appear when booting from a USB stick or when using Bootloader Chooser.
		- Enabled `GopBurstMode` &rarr; marginally reduces loading time of the OC menu

**NOTES**

- Don't update `VoodooPS2Controller.kext` and `VoodooSDHC.kext`
- Follow `OC macOS Ventura Install Instructions.md` for installing macOS 13
- Change `hibernatemode` to `25` to enable Hibernation!
- ⚠️ You cannot install macOS Security Response Updates (RSR) on pre-Haswell Systems. These kind of update will just fail to install (more info [**here**](https://github.com/dortania/OpenCore-Legacy-Patcher/issues/1019)).

### 2023-03-30: Ventura 13.3
- Updated OpenCore to 0.9.1 Nightly
- Updated `Drivers` and `Kexts`
- Updated Config to reflect latest OpenCore feature-set
- Tested successfully with macOS Mojave to Ventura

**NOTES**

- Don't update `VoodooPS2Controller.kext` and `VoodooSDHC.kext`
- Follow `OC macOS Ventura Install Instructions.md` for installing macOS 13
- Change `hibernatemode` to `25` in Hackintool or via Terminal to enable Hibernation!

### 2023-02-14
- Updated OpenCore to 0.8.9 Release
- Updated `Drivers` and `Kexts`
- Tested successfully with macOS Mojave to Ventura
- **CONFIG**
	- Disabled `EnableVectorAcceleration`. Because acceleration of SHA-512 and SHA-384 hashing algorithms requires AVX 2.0, which is only supported by Haswell and newer.
	- Added boot-arg `hbfx-ahbm=1` &rarr; Provided by HibernationFixup. Enables hibernation instead of regular sleep
- **KEXTS**
	- Added `NoTouchID` &rarr; Required for macOS High Sierra and Mojave to prevent the boot process from stalling while macOS is checking for the presence of a TouchID sensor.
	- Added `HibernationFixup` &rarr; Enables the system to enter sleep/hibernation on it's own (and stay in it) when an external monitor is attached (Big Sur and newer). 
	- Re-ordered kexts

**NOTES**

- Don't update `VoodooPS2Controller.kext` and `VoodooSDHC.kext`
- Follow `OC macOS Ventura Install Instructions.md` for installing macOS 13
- Change `hibernatemode` to `25` in Hackintool or via Terminal to enable Hibernation!


### 2023-01-04: Plugin-Type 0 working in Ventura
- Updated OpenCore to 0.8.9 nightly
- Updated `Drivers` and `Kexts`
- Tested successfully with macOS Mojave to Ventura
- **ACPI**
	- **Deleted** `SSDT-XCPM.aml` &rarr; No longer required since I managed to get ACPI SMC CPU Power Management (Plugin-Type 0) working in Ventura again!
	- **Enabled** `SSDT-PM.aml` &rarr; Enables ACPI CPU Power Management for Intel i7 3630QM. [**Generate your own**](https://github.com/5T33Z0/OC-Little-Translated/blob/main/01_Adding_missing_Devices_and_enabling_Features/CPU_Power_Management/CPU_Power_Management_(Legacy)/README.md) for your CPU using ssdtPRGen 
- **KEXTS**
	-  **Added** `AppleIntelCPUPowerManagement.kext` &rarr; Enables Legacy CPU Power Management (Plugin-Type 0) in Ventura
	-  **Added**`AppleIntelCPUPowerManagementClient.kext` &rarr; same
- **CONFIG**
	- **Kernel/Patch**: Disabled `_xcpm_bootstrap` &rarr; No longer needed, since Plugin-Type 0 can be used in Ventura
	- **Kernel/Quirks**:
		- **Disabled** `AppleXcpmCfgLock` &rarr; same
		- **Disabled** `AppeXcpmExtraMsrs` &rarr; same

**NOTES**

- Don't update `VoodooPS2Controller.kext` and `VoodooSDHC.kext`
- Follow `OC macOS Ventura Install Instructions.md` for installing macOS 13
- ⚠️ You cannot install macOS Security Response Updates (RSR) on pre-Haswell Systems. These kind of update will just fail to install (more info [**here**](https://github.com/dortania/OpenCore-Legacy-Patcher/issues/1019)). 


### 2022-31-12: Config Cleanup
- Updated OpenCore to 0.8.8 nightly
- Updated `Drivers` and `Kexts`
- Tested successfully with macOS Mojave to Ventura
- **ACPI Tables**
	- **Added** `SSDT-IRQ_FIXES.aml` &rarr; IRQ fixes for enabling Audio. Replaces `SSDT-HPET` and ACPI patches generated by SSDTTime (cleaner implementation)
	- **Added** `SSDT-XCPM.aml` for Intel i7 3630QM &rarr; Enables Turbo Stated in macOS Ventura. Basically the same as SSDT-PM but with XCPM enabled. Refer to [**Enabling XCMP on Ivy Bridge**](https://github.com/5T33Z0/OC-Little-Translated/tree/main/01_Adding_missing_Devices_and_enabling_Features/CPU_Power_Management/Enabling_XCPM_on_Ivy_Bridge_CPUs) to generate a custom SSDT for your CPU model!
	- **Modified** `SSDT-PTSWAKTTS`: Changed `MODE` from `ZERO` (`PNP0C0D` sleep) to `ONE` (`PNP0C0E` sleep) &rarr; System finally enters sleep on its own *reliably*. Details [**here**](https://github.com/5T33Z0/OC-Little-Translated/tree/main/04_Fixing_Sleep_and_Wake_Issues/PNP0C0E_Sleep_Correction_Method)
	- **Deleted** `SSDT-PM.aml` &rarr; covered by `SSDT-XCPM.aml`
	- **Deleted** `SSDT-HPET.aml` and corresponding ACPI patches. Replaced by `SSDT-IRQ_FIXES.aml` &rarr; Cleaner implementation
- **CONFIG**
	- **`ACPI/Patch`**:
		- **Added** "change WNTF to XXXX in HPET" rename. Disables original HPET and adds fake in macOS &rarr; Required for fixing IRQ conflicts so audio works.
		- **Added** "change  WXPF to YYYY in HPET" rename &rarr; same
		- **Deleted** "HPET _CRS to XCRS Rename" &rarr; No longer required, handled by `SSDT-IRQ_FIXES.aml` and WNTF/WXPF renames.
		- **Deleted** "TIMR IRQ 0 Patch" &rarr; same
		- **Deleted** "RTC IRQ 8 Patch" &rarr; same
	- **`Kernel/Patch`**: 
		- **Enabled** `_xcpm_bootstrap` patch to force enable XCPM on Ivy Bridge (Plugin Type 1) &rarr; Fixes CPU Power Management in macOS 12 and newer. Otherwise the CPU is stuck at base frequency (no Turbo States).
		- **Deleted** "Force FileVault on Broken Seal" &rarr; Redundant since I don't use FileVault
		- **Deleted** "Disable Library Validation Enforcement" &rarr; Replaced by NVRAM variable `-allow_amfi` for OCLP
		- **Deleted** "Reroute kern.hv_vmm_present patch (1)" &rarr; ; handled by `RestrictEvents.kext` and NVRAM variable `revpatch:sbvmm`
		- **Deleted** "Reroute kern.hv_vmm_present patch (2) Legacy" &rarr; same
		- **Deleted** "Reroute kern.hv_vmm_present patch (3) Ventura" &rarr; same
		- **Deleted** "Force IOGetVMMPresent" &rarr; same
		- **Deleted** "HDMI-video, 64MB BIOS, HD4000 0x01660004 (1 of 2)" &rarr; Redundant since the T530 doesn't have an HDMI port
		- **Deleted** "HDMI-video, 64MB BIOS, HD4000 0x01660004 (2 of 2)" &rarr; same
	- **`Kernel/Quirks`**: 
		- **Enabled** `AppleXcpmCfgLock` &rarr; Required for XCPM to work
		- **Enabled** `AppleXcpmExtraMsrs` &rarr; same
	- **`NVRAM/Add/4D1FDA02-38C7-4A6A-9CC6-4BCCA8B30102`**: 
		- **Added** `revblock=media` &rarr; Blocks `mediaanalysisd` service on Ventura+ which fixes issues on Metal 1 iGPUs. Firefox won't work without this.
		- **Added** `revpatch=sbvmm` &rarr; Enables VMM SB model, allowing unsupported SMBIOS and OTA updates on macOS 11.3 or newer
	- **`NVRAM/Add/7C436110-AB2A-4BBB-A880-FE41995C9F82`**:
		- **Added** boot-arg `ipc_control_port_options=0` &rarr; Resolves crashes with Electron apps like Discord in macOS 12.3+ when SIP is lowered/disabled
- **DRIVERS** 
	- **Deleted** `ToggleSipEntry.efi` &rarr; The csr value it applies when enabled (`7F020000`) is useless for running macOS 12 and newer on legacy hardware, where Bit 12 ("Allow unauthenticated root") needs to be set in order to install and load Intel HD 4000 drivers.
- **KEXTS**
	- **RestrictEvents**: changed `MaxKernel` to 20.4, so it loads for macOS Big Sur and newer only

**NOTES**

- Don't update `VoodooPS2Controller.kext` and `VoodooSDHC.kext`
- Follow `OC macOS Ventura Install Instructions.md` for installing macOS 13
- Thanks to [jozews321](https://github.com/jozews321) for the tips about improving macOS 13 support

### 2022-12-16 (Christmas comes early edition)
- Updated OpenCore to 0.8.8 nightly
- Updated `Drivers` and `Kexts`
- Tested successfully with macOS Mojave to Ventura
- **ACPI**
	- Added more `_PRW` references to `SSDT-PRW0`. Entering sleep on it's own is finally working reliably.
- **Kexts**
	- Added `CryptexFixup.kext` to be able to boot macOS Ventura
- **Config**
	- Added `amfi_get_out_of_my_way=1` boot-arg so Intel HD 4000 drivers can be installed in macOS Ventura
 
**NOTES**

- Don't update `VoodooPS2Controller.kext` and `VoodooSDHC.kext`
- Follow `OC macOS Ventura Install Instructions.md` for installing macOS 13

### 2022-12-08
- Updated OpenCore to 0.8.8 nightly
- Updated `Drivers` and `Kexts`
- Tested successfully with macOS Catalina to macOS Monterey
- **ACPI**
	- Added `ACST` to `OCST` rename to prevent conflicts related to C-States in macOS
- **Booter**
	- Added MMIO Whitelist entries
	- Enabled `DevirtualiseMmmio` Quirk 

**NOTES**

- Don't update `VoodooPS2Controller.kext` and `VoodooSDHC.kext`
- Follow `OC macOS Monterey Install Instructions.md` for installing macOS 12

### 2022-11-03
- Updated OpenCore to 0.8.6 nightly
- Updated `Drivers` and `Kexts`
- Tested successfully with macOS Catalina to macOS Monterey
- **CONFIG**
	- Disabled `Kernel/Scheme/FuzzyMatch` &rarr; only required for legacy OSX up to 10.6
	- Disabled `UEFI/Quirks/ActivateHpetSupport` &rarr; improves performance

**NOTES**

- Don't update `VoodooPS2Controller.kext` and `VoodooSDHC.kext`
- Follow `OC macOS Monterey Install Instructions.md` for installing macOS 12

### 2022-09-22
- Updated OpenCore to 0.8.5 nightly
- Updated `Drivers` and `Kexts`
- Tested successfully with macOS Catalina to macOS Monterey
- **ACPI**
	- Added `SSDT-TEMPToFans` &rarr; optimizes Fan behavior (supposedly)
- **CONFIG**
	- Added `No-hda-gfx` property to Audio Device &rarr; Disables audio over `HDMI`/`DisplayPort`. Disable/Delete this key if you need digital audio via your monitor cable.
	- Changed `Misc/DmgLoading` from `Any` to `Signed`

**NOTES**

- Don't update `VoodooPS2Controller.kext` and `VoodooSDHC.kext`
- Follow `OC macOS Monterey Install Instructions.md` for installing macOS 12

### 2022-08-19: Major Update
- Updated OpenCore to 0.8.4 nightly
- Updated `Drivers` and `Kexts`
- Tested successfully with macOS Catalina to macOS Monterey
- Finally fixed the last remaining issue where the machine wouldn't enter Sleep/Hibernation on its own if it wasn't triggered by the user via the  menu or by closing the lid!
- **ACPI**
	- Added [**`SSDT-PRW0`**](https://github.com/5T33Z0/OC-Little-Translated/tree/main/04_Fixing_Sleep_and_Wake_Issues/060D_Instant_Wake_Fix#method-2-using-ssdt-prw0aml-no-gprwuprw) &rarr; Sets 2nd bytes or `_PRW` packages to `0`. Replaces the previously used 0D/6D-03, 0D/6D-04 binary renames. Cleaner, way more elegant and applies to macOS only.
	- Deleted `SSDT-Sleep_PRW-0D6D` &rarr; no longer required	- Deleted `SSDT-LID` &rarr; not required
	- Deleted `SSDT-AC` &rarr; Cosmetic only. Handled by `SMCBatteryManager.kext`
- **CONFIG**
 	- Deleted "change 0D-03 to 00, pair with SSDT-Sleep_PRW-0D6D.aml"
	- Deleted "change 0D-04 to 00"
	- Deleted "change 6D-03 to 00"
	- Deleted "change 6D-04 to 00" &rarr; No longer required, handled by `SSDT-XPRW`
	- Deleted "change _LID to XLID" &rarr; redefining the method is not required.
	- Deleted "change SAT1 to SATA"
	- Deleted "change EHC1 to EH01 (USB)"
	- Deleted "change EHC2 to EH02 (USB)"
	- Deleted "change XHCI to XHC_ (USB)" &rarr; unnecessary Device Renames
- **KEXTS**
	- Deleted `HibernationFixup.kext` &rarr; not required.

**NOTES**

- Don't update `VoodooPS2Controller.kext` and `VoodooSDHC.kext`
- Follow `OC macOS Monterey Install Instructions.md` for installing macOS 12
- When I first started converting this machine from a patched DSDT to using SSDTs, more than 20 binary renames were required to fix Battery status, Device Names, Fn Keys and Sleep/Wake issues – now, only 8 are required. The rest have been substituted by Kexts (ECEnabler, Brightnesskeys) and/or SSDTs. The number of required SSDTs has also been reduced. The system runs super smooth. I think this is as good as it gets.

### 2022-08-11
- Updated OpenCore to 0.8.4 nightly
- Updated `Drivers` and `Kexts`
- Tested successfully with macOS Catalina to macOS Monterey
- **ACPI**
	- Deleted `SSDT-XDSM.aml` &rarr; Prevents the system from entering sleep/hibernation on its own
	- Deleted `SSDT-XOSI.aml` &rarr; Unnecessary. The TrackPad works fine without it.
	- Deleted `SSDT-FWHD.aml` &rarr; Unnecessary.
- **CONFIG**
	- Deleted `change DSM to XDSM` &rarr; Unnecessary 
	- Deleted `change _OSI to XOSI` &rarr; Unnecessary
	- Deleted `change OSIF to XSIF` &rarr; Unnecessary
- **KEXTS**
	- Added `HibernationFixup.kext` &rarr; fixes entering Sleep/Hibernation when it is not triggered by the user via the  menu.

**NOTES**

- Don't update `VoodooPS2Controller.kext` and `VoodooSDHC.kext`
- Follow `OC macOS Monterey Install Instructions.md` for installing macOS 12
 
### 2022-08-02
- Updated OpenCore to 0.8.4 nightly
- Updated `Drivers` and `Kexts`
- Tested successfullywith macOS Catalina to macOS Monterey
- **ACPI**: 
	- Disabled `SSDT-XDSM.aml` &rarr; Prevents the system from entering sleep/hibernation on its own
	- Disabled `SSDT-XOSI.aml` &rarr; Unnecessary. The TrackPad works fine without it.
- **CONFIG**
	- Added Block rule to block `Apple16X50.kext` fom loading &rarr; Disables PCI Serial Adapter from showing in Network Settings (you still need to delete the entry).
	- Disabled `change DSM to XDSM` &rarr; not necessary if `SSDT-XDSM.aml` is disabled
	- Disabled `change _OSI to XOSI` and `change OSIF to XSIF` &rarr; not necessary if `SSDT-XOSI.aml` is disabled
	- Enabled `Kernel/Quirks/CustomSMBIOSGuid` and changed `PlatformInfo/UpdateSMBIOSMode` to `Custom` &rarr; Prevents SMBIOS data injection into Windows
- **DRIVERS**
	- Added `ResetNvramEntry.efi` &rarr; To enable NVRAM reset from BootPicker.

**NOTES**:

- Don't update `VoodooPS2Controller.kext` and `VoodooSDHC.kext`
- Follow `OC macOS Monterey Install Instructions.md` for installing macOS 12

### 2022-07-18
- Updated OpenCore to 0.8.3 nightly
- Updated `Drivers` and `Kexts`
- Tested successfully with macOS Catalina to macOS Monterey
- **CONFIG**
	- Added Block rule to block `Apple16X50.kext` fom loading &rarr; Disables PCI Serial Adapter from showing in Network Settings (you still need to delete the entry). 

**NOTES**:

- Don't update `VoodooPS2Controller.kext` and `VoodooSDHC.kext`
- Follow `Monterey Install Instructions.md` for installing macOS 12.5

### 2022-06-30
- Updated OpenCore to 0.8.2 nightly
- Updated `Drivers` and `Kexts`
- Updated config to latest feature-set
- Tested successfully with macOS Catalina to macOS Ventura
- **KEXTS**
	- **AppleALC**: I created an AppleALC Layout-ID which supports the line-out of Docking stations 4337 and 4338 and compiled a custom version of AppleALC which only includes LayoutIDs 18 and 39. Layout 18 is for using the Laptop as is, Layout 39 is for connecting external Speakers to the Line-Out of the Docking Station. It's only 95 kB in size instead of 3,8 MB of the Release version!

**NOTES**:

- Don't update `VoodooPS2Controller.kext` and `VoodooSDHC.kext`
- Follow `Monterey Install Instructions.md` for installing macOS 12.5
### 2022-06-06
- Updated OpenCore to 0.8.1
- Updated `Drivers` and `Kexts`
- Updated config to latest feature-set
- **CONFIG**
	- Deleted `-gux_defer_usb2` boot-arg. It's for a legacy kext not used in my EFI
	- Added boot-arg `revpatch=diskread,memtab` for `RestrictEvents.kext` (remove `#` to enable it) &rarr; Enables "Memory" tab in "About this Mac" section and disables "Uninitialized Disk" warning (for macOS 10.14 and older).
	- Updated `MinKernel` settings in `Kernel/Add` section
	- DeviceProperties: Added `enable-backlight-smoother` to Framebuffer patch &rarr; smoothens transitions when changing brightness (remove `#` to enable)
	- Removed `TableSignature` from binary renames EHC1/EHC2, SAT1, XHCI to avoid undefined references in other tables besides `DSDT`.
- **DRIVERS**
	- Added `ResetNvramEntry.efi` &rarr; replaces deprecated "AllowNvramReset"
	- Removed `CleanNVRAM.efi` from "Tools"  &rarr; no longer required
- **KEXTS**
	- AppleALC: I compiled a custom version for use with ALC269 Codec supporting LayoutIDs 18 and 39 only. Layout 18 is for using the Laptop as is, Layout 39 is for connecting external Speakers to the Line-Out of a Docking Station (HeadPhone out doesn't work on Layout 39). It's only 95 kB in size instead of 3,8 MB of the Release version!
	- Added `RestictEvents.kext` (disabled by default)

**NOTES**:

- Don't update `VoodooPS2Controller.kext` 
- Don't update `VoodooSDHC.kext`
- Follow `Monterey Install Instructions.md` for installing macOS 12.3

### 2022-04-18
- Updated OpenCore to 0.8.1 nightly
- Updated `Drivers` and `Kexts`
- **Resources**: Added [EnterTwilight](https://github.com/velickovicdj/OpenCanopy-EnterTwilight) theme by velickovicdj

**NOTES**:

- Don't update `VoodooPS2Controller.kext` 
- Don't update `VoodooSDHC.kext`
- Follow `Monterey Install Instructions.md` for installing macOS 12.3

### 2022-04-01

- Updated OpenCore 0.8.0 nightly
- Updated `Drivers` and `Kexts`
- **CONFIG**:
	- Added new `Misc` &rarr; `Serial` section
	- Updated `Misc` &rarr; `Debug` settings to reflect latest OpenCore defaults

**NOTES**:

- Don't update `VoodooPS2Controller.kext` 
- Don't update `VoodooSDHC.kext`
- Follow `Monterey Install Instructions.md` for installing macOS 12.3

### 2022-03-08
- Updated OpenCore 0.8.0 nightly
- Updated `Drivers` and `Kexts`
- Tested with macOS 12.3 beta 5
- Changed `SetApfsTrimTimeout` to `0` to support new method to disable trim in macOS 12.

**NOTES**:

- Don't update `VoodooPS2Controller.kext` 
- Don't update `VoodooSDHC.kext`
- Follow `Monterey Install Instructions.md` for installing macOS 12.

### 2022-02-10
- Updated OpenCore 0.7.9 nightly
- Updated `Drivers` and `Kexts`
- Tested with macOS 12.3 beta 4
- Added `SSDT-FWHD.aml` &rarr; Adds Intel Firmware Hub Device

**NOTES**:

- Don't update `VoodooPS2Controller.kext` 
- Don't update `VoodooSDHC.kext`
- Follow `Monterey Install Instructions.md` for installing macOS 12.

### 2022-01-12
- Updated OpenCore 0.7.8 nightly
- Updated `Drivers` and `Kexts`
- Tested with macOS 12.2 beta
- **CONFIG**
	- Updated `config.plist`to reflect latest OpenCore feature-set
	- Added bootchime support (set `AudioDxe.efi` to `true` to enable it!)
	- Kernel > Quirks: unchecked `DisableIoMapper` &rarr; unnecessary. The system boots fine with with Vt-D enabled!
	- Changed ScanPolicy to `0`
	- Enabled `JumpstartHotPlug`

**NOTES**:

- Don't update `VoodooPS2Controller.kext` 
- Don't update `VoodooSDHC.kext`
- Follow `Monterey Install Instructions.md` for installing macOS 12.

### 2022-01-01
Happy new year!

- Updated OpenCore 0.7.7 nightly
- Updated `Drivers` and `Kexts`
- Updated `config.plist`to reflect latest OpenCore feature-set
- Tested with macOS 12.2 beta
- **ACPI**:
	- Deleted `SSDT-AC.aml`→ Cosmetic only. Not required when using `SMCBatteryManager.kext`.
	- Deleted `SSDT-BKEYS.aml` → replaced by `BrightnessKeys.kext`
	- Added `SSDT-NBCF.aml` → sets `NBCF` to `1` for macOS. Required for `BrightnessKeys.kext` to work.
- **KEXTS**:
	- Deleted `ACPIBatteryManager.kext` → outdated
	- Added `SMCBatteryManager.kext` → replaces ACPIBatteryManager
	- Added `BrightnessKeys.kext` → Enables Brightness Hotkeys
- **CONFIG**:
	- ACPI > Patch: deleted `Q14` and `Q15` renames → no longer required (handled by `BrightnessKeys.kext` instead), since Renaming `_Qxx` methods in `EC` is not recommended (see OpenCore Documentation).
	- Added `ScanPolicy`

**NOTES**:

- Don't update `VoodooPS2Controller.kext` 
- Don't update `VoodooSDHC.kext`
- Don't install `FeatureUnlock.kext` → causes Kernel Panic on Boot
- Follow `Monterey Install Instructions.md` for installing macOS 12.

### 2021-12-16
- Updated OpenCore 0.7.7 nightly
- Updated `Drivers` and `Kexts`
- Updated `config.plist`to reflect latest OpenCore feature-set
- Tested with macOS 12.1 (21C52) 
- **ACPI**: 
	- Added `SSDT-BAT1-disable.aml` → Disables the optional 2nd Battery (`BAT1`)
	- Deleted `SSDT-GPRW.aml` → Method doesn't exist in `DSDT` 
- **KEXTS**: 
	- Added `ACPIBatteryManager.kext` → Connects AC Adapter to `AppleACPIACAdapter` service and attaches `BAT0` to `AppleSmartBatteryManger` in IOReg
	- Deleted `SMCBatteryManager.kext` → superfluous
	- Removed `RestrictEvents.kext` → no longer required.
- **CONFIG**:
	- ACPI > Patch: changed `STA` to `XSTA` for `BAT1`
	- ACPI > Patch: deleted `GPRW` to `XPRW` → Method doesn't exist in `DSDT`
	- ACPI > Quirks: enabled `ResetLogoStatus` since value for `Displayed` in `BGRT.aml` table is not `0`.
	- Added `gfxrst=1` boot-arg. Draws the Apple Logo during the 2nd boot stage instead of framebuffer copying → Smoother transition from the progress bar to the Desktop/Login Screen if an external monitor is attached. 
	- Moved `applbkl` from boot-args into the Framebuffer Patch Property.

**NOTES**:

- Don't update `VoodooPS2Controller.kext` 
- Don't update `VoodooSDHC.kext`
- Don't install `FeatureUnlock.kext` → causes Kernel Panic on Boot
- Follow `Monterey Install Instructions.md` for installing macOS 12.

### 2021-11-07
- Updated OpenCore 0.7.6
- Updated `Drivers` and `Kexts`
- Updated `config.plist`to reflect latest OpenCore feature-set
- **ACPI**: 
	- Added `SSDT-AC.aml` → Connects AC Power Adapter with `AppleACPIACAdapter` in IOReg
	- Added `SSDT-GPRW.aml` → Restricts 0d/6d renames to macOS
- **CONFIG**:
	- Disabled `RestrictEvents.kext` → no longer required for updating macOS Monterey (supposedly)
	- Deleted entries for `UIScale` from NVRAM section since it's now a Key in UEFI > Output.
	- Added `GPRW to XPRW` rename → replacement method to constrain power-status-related 0d/6d renames to macOS.
	- Re-enabled `EHC1 to EH01`and `EHC2 to EH02` renames but removed PCI paths from "base" → fixes USB Controllers in macOS and resolves ACPI errors in Windows 11.
	- Re-enabled `SAT0 to SATA` rename but removed PCI path from "base" → resolves ACPI errors in Windows 11.

**NOTES**:

- Don't update `VoodooPS2Controller.kext` and `VoodooSDHC.kext`!
- Follow `Monterey Install Instructions.md` for installing macOS Monterey

### 2021-10-29: MAJOR UPDATE!!!
- Updated OpenCore 0.7.5
- Updated `Drivers` and `Kexts`
- Updated `config.plist`to reflect latest OpenCore feature-set
- **CONFIG**:
	- Added Booter and Kernel Patches to skip Board-ID checks and spoofs a supported one to Apple update servers via VMM, which has the following benefits:
		- Allows using the correct SMBIOS for Ivy Bridge CPUs (MacBookPro 9,x/10,x) without -no_compat_check on macOS Monterey. 
		- Allows booting and installing macOS Monterey and System Updates via Software update with unsupported SMBIOS. 
		- Improves CPU Power Management, because changing the SMBIOS is no longer necessary!

**NOTES**:

- Don't update `VoodooPS2Controller.kext`!
- Follow updated `Monterey Install Instructions.md` for installing macOS 12 Monterey on the Lenovo T530

### 2021-10-26

- Updated OpenCore 0.7.5
- Updated `Drivers` and `Kexts`
- Updated `config.plist`to reflect latest OpenCore feature-set
- **ACPI**: Disabled `SSDT-PWRB.aml` → unnecessary
- **KEXTS**: Added `BrcmPatchRAM2.kext` → Required for macOS HighSierra and Mojave
- **CONFIG**:
	- Changed `MinKernel` to 15.0.0 and `MaxKernel` to 18.9.9 for `BrcmPatchRAM2.kext` → enables kext for macOS 10.11 to 10.14 only.
	- Changed `MinKernel` to 19.0.0 for `BrcmBluetoothInjector.kext` → enables kext fo macOS Catalina and Big Sur only
	- Updated XCPM Kernel Patch; changed `MaxKernel` to `21.9.9` → enables XCPM on macOS Monterey 12.0.1. It still works!
- **THEMES**: Added and enabled [BsxM1](https://github.com/blackosx/BsxM1) by Blackosx

**NOTES**:

- Don't update `VoodooPS2Controller.kext`!
- Follow updated `Monterey Install Instructions.md` for installing macOS 12 Monterey on the Lenovo T530

### 2021-10-17
- Updated OpenCore 0.7.5
- Updated `Drivers` and `Kexts`
- Updated `config.plist`to reflect latest OpenCore feature-set
- **ACPI**: Updated `SSDT-XOSI.aml` for Windows 11 compatibility
- **CONFIG**:
	- Disabled the following renames to prevent Windows 11 boot crashes:
		- change EHC1 to EH01 (USB)
		- change EHC2 to EH02 (USB) 
		- change SAT1 to SATA (Disk)
	- Updated `MinKernel` and `MaxKernel` for Broadcom Kexts → `BrcmPatchRAM` and `BrcmFirmwareData` kexts are no longer required for macOS Monterey.		
**NOTES**:

- Don't update `VoodooPS2Controller.kext`!
- Follow updated `Monterey Install Instructions.md` for installing macOS 12 Monterey on the Lenovo T530

### 2021-10-04
- Updated OpenCore 0.7.4 Release
- Updated `Drivers` and `Kexts`
- Fixed an issue where SIP would prohibit the system from booting
- Added `RestrictEvents.kext` → enables installing macOS Monterey on every Mac model
- **CONFIG**:
	- Changed `ExposeSensitiveData` from `7` to `3` → removes OpenCore version from Bootmenu for a cleaner, more "vanilla" macOS-like look
	- Changed `PickerVariant` to `Auto`
	- Added `base` path to `EHC1`, `EHC2`, `XHCI` and `SAT1` → cleaner and more precise device renames
	- Enabled `AdviseFeatures` to avoid Firmware check errors during macOS Monterey beta 8 installation
	- Changed layout-id for Audio from `29` to `40` → mapped for ThinkPad W530 which uses the same audio codec as the T530.

**NOTES**:

- Don't update `VoodooPS2Controller.kext`!
- Follow updated `Monterey Install Instructions.md` for installing macOS 12 Monterey on the Lenovo T530

### 2021-09-24
- Updated OpenCore 0.7.4 to Commit f7d37d0
- Updated Drivers and Kexts
- Updated `config.plist`to reflect latest OpenCore feature-set
- Removed `config_Monterey.plist` → no longer needed.
- **CONFIG**:
	- Changed default `SystemProductName` to `MacBookPro11,4` → compatible with High Sierra up to Monterey. **NOTE**: For better thermals and CPU power management use `MacBookPro10,1` with `-no_compat_check` boot-arg
	- Set `MaxKernel` to `20.9.9` for `BrcmBluetoothInjector.kext` → restricts loading of this kext to macOS Big Sur and older.
	- Set `MinKernel` to `21.0.0` for `BlueToolFixup.kext` and `BlueToolFixup.kext` → restricts loading of these Kexts to macOS Monterey and newer.</br> **NOTE**: Loading diverging sets of kexts (for macos 12 specifically) is now handled by `MaxKernel` and `MinKernel`, which sets the range of Darwin Kernels a kext is loaded for. This allows to leave otherwise conflicting kexts enabled because their on and off state is based on the active Darwin Kernel.
	- Removed Key `VGA Compatible Controller` from Framebuffer Patches → fixes VESA Mode (necessary for installing macOS Monterey)
	- Changed `ConsoleMode` from `Max`to blank as recommended 
	- Disabled `JumpstartHotPlug` as recommended → only necessary when connecting external APFS volume(s) via USB.
	- Changed `PickerVariant` to `Acidanthera\Syrah` → Windows Drive Icon is looking better
	
**NOTES**:

- Don't update `VoodooPS2Controller.kext`!
- Follow `Monterey Instructions.md` for installing macOS 12 Monterey on the Lenovo T530.

### 2021-09-08
- Updated OpenCore to 0.7.4 Nightly
- Updated `config.plist` and `config_Monterey.plist` to reflect latest OpenCore feature-set
- Updated Comments in configs
- Audio: reverted Layout-ID from `28` back to `29` → Audio wouldn't work on internal speakers after waking up from sleep.
- Added `ECEnabler.kext` which enables macOS to get the battery status from the Embedded Controller, so no more Battery Patches are required! More info [here](https://www.reddit.com/r/hackintosh/comments/n2nvf8/ecenabler_no_more_acpi_patches_for_battery_sorta/).
- Deleted `SSDT-Battery.aml` → no longer necessary
- Deleted all Binary Renames related to Battery Status (13 in total!) → no longer necessary.
- `VoodooPS2Keyboard.kext` plugin: changed the behavior of [CMD] and [Option] keys from swapped to regular, so that the [Windows] and [Alt] Keys behave as expected by default. If you are updating from a previous Release, reset the Modifier Keys under System Settings > Keyboard back to `Default`.
- Enabled UEFI > Quirks > `ForceOCwriteFlash` → From the Documentation: "Boot issues across multiple OSes can be observed on T530 without this quirk"

**NOTES**: 

- Don't update `VoodooPS2Controller.kext`!
- Follow `Monterey Instructions.md` for installing macOS 12 Monterey on the Lenovo T530.

### 2021-09-06
- Updated OpenCore to 0.7.3 Release
- Updated `Drivers`, `Kexts` and `Resources`
- **CONFIG**:
	- Updated `config.plist` and `config_Monterey.plist` to reflect latest OpenCore feature-set
	- Updated `UEFI` > `Drivers` Section. **BACKGROUND**: During development of OpenCore 0.7.3, this section was changed from a simple list to an Array with Dictionaries for each Driver, providing additional options to enable/disable and assigning extra arguments to them (refer to `sample.plist`). So if you were wondering why your Boot Picker GUI was gone and your system won't boot after updating OpenCore – that's why.
	- Added `device-id` for IvyBridge CPU to framebuffer patch
	- Updated `MinKernel` and `MaxKernel` Section for Kexts
	- Disabled `ExternalDiskIcons` Quirk → unnecessary
- **RESOURCES**:
	- Added 2 additional Boot Picker icon sets by [chris1111](https://github.com/chris1111/My-Simple-OC-Themes): "Minimal" and "Minimal-SSD". Change `PickerVariant` to either `chris1111\Minimal` or `chris1111\Minimal-SSD` to apply them (check "Flavors" Folder for Previews).

**NOTE**: Color coding for Kexts: <span style="color:red">**RED**</span> = don't update this Kext! <span style="color:orange">**ORANGE**</span> = Kext is used in macOS Monterey only.

### 2021-08-03
- Updated OpenCore to 0.7.2 Release.
- Updated `Drivers`, `Kexts` and `Resources`.
- **ACPI**:
	- Updated `SSDT-PNLF.aml` based on latest ACPI Samples to improve Windows Compatibility
- **CONFIG**:
	- Updated `config.plist` to reflect latest OpenCore feature-set.
	- Added `config_Monterey.plist`
	- Audio: changed Layout-ID from `29` to `28` → Fixes line-out level being lower than normal if speakers/headphones are plugged-in during boot.
	- Updated `Arch` and `MinKernel` Infos
	- Changed UEFI > APFS > `MinDate` and `MinVersion` to `-1` → Enables APFS Driver loading for *any* macOS Version. Otherwise, if you use macOS lower than Big Sur and the values are left to defaults (set to `0`) you won't see your macOS Partition. **NOTE**: For security reasons you should change these values according to the macOS version you are running. A list with the correct values can be found [here](https://github.com/acidanthera/OpenCorePkg/blob/master/Include/Acidanthera/Library/OcApfsLib.h).

### 2021-07-08

- Merged regular EFI Folder and Monterey Edition 
- Added `config_Monterey.plist` to the EFI Folder. Rename to `config.plist` to boot macOS 12.0 beta
- Added `BluetoolFixup.kext` for making Bluetooth work in macOS 12 beta

### 2021-07-06
- Updated OpenCore to 0.7.2 Nightly.
- Updated `Drivers`, `Kexts` and `Resources`.
- Updated `config.plist` to reflect latest OpenCore feature-set.
- reinstated `framebuffer-unifiedmem` in Framebuffer Patch for 2 GB graphics RAM to fix small glitches.

**NOTE**: Configured for use with macOS Catalina primarily. Big Sur needs changes in SMBIOS as well as csr-active config. macOS Monterey needs a different EFI altogether (check `Releases` Section) plus modifications to the Installation itself to patch in Intel HD4000 graphics support. Follow the EFI install Instruction on my github repo.

### 2021-06-07
- Updated OpenCore to 0.7.0 Release Version.
- Updated `Drivers`, `Kexts` and `Resources`.
- Fixed Brightness Fn Keys not working under Windows 10.
- Removed `BrightnessKeys.kext` and corresponding binary rename in favor of `SSDT-BKEYS.aml` to enable Brightness Fn Keys → ACPI method is cleaner, plus it's one less Kext to worry about in the future.
- **ACPI:**
	- Added `SSDT-BKEYS.aml` → enables Brightness Fn Keys
	- Added `SSDT-XDSM.aml` → restricts `_DSM` to `XDSM`rename to specified devices in macOS only.
	- Removed `SSDT-XCPM.aml` for enabling `X86PlatformPlugin` → there are no benefits in using it on Ivy Bridge CPUs. If anything, performance is reduced significantly.
- **CONFIG:**
	- Updated `config.plist` to reflect latest OpenCore feature-set.
	- Updated Comments.
	- Enabled new `AllowToggleSip` feature → Adds option to override the current setting for `csr-active-config` to the BootPicker, thereby temporarily enabling/disabling SIP. In other words: if SIP is disabled by default it enables it and if SIP is on, it turns it off until next boot.
	- Changed `PickerVariant` to `Acidanthera/GoldenGate` to test new content flavor system. *GoldenGate* = BigSur Icon Set. Default = `Auto`.
	- Added `DMAR` and `MATS` to `ACPI > Delete` to drop these Tables.
	- Added placeholder entries (commented-out by `#`) with values for `Syrah Black` and `Light Grey` to NVRAM > Add > 4D1EDE05-38C7-4A6A-9CC6-4BCCA8B38C14 > `DefaultBackgroundColor`
	- Re-enabled `ActivateHpetSupport` Quirk for improved Hyper Threading performance.
	- Re-enabled `_DSM` to `XDSM` rename → fixes machine not entering sleep on it's own.
	- Re-enabled `_Q14` to `XQ14` and `_Q15` to `XQ15`renames to make Brightness Fn Keys work without `BrightnessKeys.kext`. Added `base` ACPI path to limit these renames to specified location.
	- Disabled Misc > Debug > `AppleDebug` and `ApplePanic`
	- Disabled `framebuffer-unifiedmem` (2048 MB stolen) in favor of `framebuffer-stolenmem` (1536 MB stolen) in Device Properties > `PciRoot(0x0)/Pci(0x2,0x0)`as recommended by Framebuffer Patching Guide → more responsive GUI and faster website display.
	- Deleted unnecessary `ACST` to `OCST` rename.
	- Deleted `DSDT` as target `TableSignature` for `change PCI0.VID to IGPU` renames → Fixes Brightness Fn Keys under Windows.

**NOTE:** This EFI is completed, imo. Any future release will probably be maintenance updates only – if any.

### 2021-05-12
- Updated OpenCore to the latest commit of 0.7.0 nightly
- Updated Drivers and Kexts
- Fixed Hibernation. System wouldn't enter Hibernation properly on its own.
- Added `BrightnessKeys.kext` to get rid of binary renames and additional SSDT necessary to make Brightness Keys work in macOS.
- **CONFIG:**
	- Updated Config to reflect latest feature-set
	- Removed DSDT-based config → no longer necessary
	- Added `Name (NBCF, 0x00)` to `Name (NBCF, 0x01)` rename so `BrightnessKeys.kext`works.
	- Added `FixACST` **Background**: The system `DSDT.aml` contains the method `ACST` in `PSR`(= Power Source) for device `AC`, but ACST is also used by macOS 10.8+ to control C-States! As a result, a completely implicit conflict with very unclear behavior can occur. This fix renames all occurrences of `ACST` to `OCST`.
	- Deleted `CMOR to XMOR` rename
	- Deleted `_Q14 to XQ14` and `_Q15 to XQ15`→ no longer necessary since `BrightnessKeys.kext` is used to make Brightness Keys work instead.
- **ACPI:**
	- Updated `SSDT-XOSI.aml` → added latest version of Windows 10
	- Removed `SSDT-BKeys-Q14Q15.aml` → no longer necessary since `BrightnessKeys.kext` is used
	- Removed `SSDT-CMOR.aml` → didn't improve Fan behavior at all
	- Removed `SSDT-ThinkPad-Fan.aml`→ didn't improve Fan behavior
	- Removed `SSDT-XDSM.aml`→ deleted for max compatibility with Windows
	
### 2021-05-03

- Updated OpenCore to version 0.7.0 nightly
- **CONFIG**:
	- Updated config to reflect the latest OpenCore feature-set
	- Removed unused Framebuffer Patch from `DeviceProperties`
	- Corrected wrong value in `#csr-active-config (High Sierra)`
	- Changed `ExposeSensitiveData`to `7` to display OpenCore build info in BootPicker
	- Disabled `ActivateHpetSupport` to increase performance.
	- Added `SAT1 to SATA` rename
	- Added `XCHI to XHC` rename
	- Added `_DSM to XDSM` rename
	- Removed `XHC1 to SHCI` rename → Device doesn't exist in `DSDT`
	- Removed `GPRW to XPRW` rename → Method doesn't exist in `DSDT`
	- Re-enabled `ConnectDrivers` for maximum compatibilty
- **KEXTs**:
	- Updated Kexts
	- Deleted unused Plugins from `VoodooPS2Controller.kext` and `config.plist`.
	- Updated entries and comments for `AirportBrcmFixup` and `BrcmBluetoothInjector`
- **ACPI**:
 	- Replaced `SSDT-SBUS-MCHC.aml` with the latest official version by Acidanthera
 	- Removed `SSDT-GPRW.aml` → method doesn't exist in `DSDT`
	- Changed device names and methods in `SSDT-XDSM.aml` to be consistent with renames used in `config.plist`
 	- Replaced `SSDT-OC-XOSI.aml` by the one from Dortania
	- Edited Windows entries in `SSDT-XOSI.aml` to reflect those present in `DSDT`, added entry for current Windows 10 build (20H2)
	
### 2021-04-05

- Upated OpenCore to version 0.6.9 nightly
- Updated Config.plist with new Array `AppleEvent` under `UEFI`
- Remove unused/moved entries from `config.plist`
- Updated Resources
- Updated `HfsPlus` Driver
- Added missing Parameters `Base`and `BaseSkip` to some ACPI > Patch entries 
- Renamed USB Controllers `EHC1`,`EHC2` and `XHC1`to avoid possible USB conflicts. Use Terminal to check the following. If nothing returns, you're good:
	- `ioreg -l -p IOService -w0 | grep -i EHC1`
	- `ioreg -l -p IOService -w0 | grep -i EHC2`
 	- `ioreg -l -p IOService -w0 | grep -i XHC1`
- Fixed Kernel > Patch CapriConnectors Patch for HDMI Connectors. Disabled, since unused.
- Validated config. 1 Error. Can be ignored.

**NOTE**: don't edit the config with OpenCore Configurator. It adds back in features which are no longer used, thereby producing errors on boot

### 2021-04-02

- Updated OpenCore to v0.6.8
- **KEXTs**:
	- Reverted `VoodooPS2Controller.kext` to a fixed variant of v 1.9.2 compatible with the current OpenCore versions > working flawlessly, no trackpad deadzones, super smooth and precice reaction!
	- fixed `TrackPoint` scrolling. X and Y multipliers were way too high - reduced them from `20` to `2` and now it is useable again.
- **ACPI**:
	- sorted out all the renames and organized them alphabetically
	- Renamed ACPI Hotpatches for a tidier look
	- added comments to Renames and SSDTs  
	- Added/replaced the following SSDTs:
		- `CMOR to XMOR` Rename, paired with `SSDT-CMOR.aml` to deactive `DSDT` Fan Control method and replace it with `SSDT-ThinkPad-Fan.aml` for changing system fan behavior
		- `SSDT-EXT4.aml` → From here…
		- `SSDT-EXT5.aml`
		- `SSDT-GPRW.aml`
		- `SSDT-LID.aml` … to here: new SSDTs for fixing sleep wake, Lid and power LED 
		- `SSDT-XDSM.aml` → disables certain devices in system `DSDT` so they can be replaced
- **Performance Improvements**:
	- System runs steadier in idle - almost no cpu spikes -> less Fan activity
	- System reacts snappier overall
	- Benchmark improved again. This is as good as it gets. 
	- **NOTE**: Stay on macOS Catalina. The performence is just better.
- **Remaining Issues** (still):
	- ~~LED pulsing after quitting sleep~~ FIXED!
	- On Lid Close
		- no Hibernation when closing the Lid
		- no switching over the primary display to external monitor (Clamshell Mode). It works without issues in Clover, in OC I couldn't figure it out yet :( Maybe I can utilize the "base" parameter insdie of renames to address it.

### 2021-03-07

* Updated OpenCore and Drivers to version 0.6.8
* **Kexts**:
	* Updated all Kexts
	* Added `BrcmFirmwareData.kext`. Delete `BrcmFirmwareRepo.kext` from Library > Extensions if present to keep it Vanilla.
	* Removed unneccessary kexts (`SMC Sensors` and `NoTouchID`)
	* Replaced `VoodooPS2Controller.kext` 1.9.2 with 2.2.2. The version from Rehabman has become incompatible with OpenCore and prevents boot.
* **ACPI**:
	* Added`SSDT-ThinkPad_TrackPad.aml` to make Trackpad work. Tweaked a few parameters to make it feel less sluggish. Still not as good as before.
	* Added `SSDT-ThinkPad-Fan.aml`
	* Fixed Windows ACPI Errors when using `config_DSDT.plist`. Windows 10 can now be started when using the config based on the patched DSDT.
* Enabled Mouse Support for Bootpicker (`PickerAttributes` = 17)
* Disconnected drivers to reduce waiting time between Lenovo Logo and Bootpicker
* Disabled Boot Chime and removed `AudioDXE.efi`
* Enabled `ActivateHpetSupport` Quirk

**NOT Working**: the new VoodooPS2 Controller Kext breaks Mouse Button Support when using `config_DSDT.plist`. Use DSDT-less config instead!

**NOTES**

- Color coding in `ACPI` folder refers to `.aml` files. <span style="color:green">**GREEN = enabled and working**</span>, <span style="color:gray"> 
- Color coding in `Kext` folder: <span style="color:red">**RED**</span> = don't update this Kext!
<span style="color:orange">**ORANGE**</span> = Kext is used in macOS Monterey only.
- If you would like to enable XCPM (not recommended) read this first: [Enabling XCPM for Ivy Bridge](https://github.com/5T33Z0/Lenovo-T530-Hackinosh-OpenCore/blob/main/Guides/Enable%20XCPM.md).
</details>
